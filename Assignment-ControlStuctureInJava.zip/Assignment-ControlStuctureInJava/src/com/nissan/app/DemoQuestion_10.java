/**
 * 
 */
package com.nissan.app;

import java.util.Scanner;

/**
 * @author NDH00880
 *
 */
public class DemoQuestion_10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
              readMonth();}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
   private static void readMonth()
   {
	   while(true){ Scanner sc=new Scanner(System.in);
		System.out.println("Enter the month:");
		System.out.println("1: January");
		System.out.println("2: February");
		System.out.println("3: March");
		System.out.println("4:April");
		System.out.println("5:May");
		System.out.println("6:June");
		System.out.println("7:July");
		System.out.println("8:August");
		System.out.println("9:sep");
		System.out.println("10:OCT");
		System.out.println("11:Nov");
		System.out.println("12:Dec");
		int month=sc.nextInt();
	
		switch(month)
		{
		case 1:
			System.out.println("January");
			break;
		case 2:
			System.out.println("February");
			break;
		case 3:
			System.out.println("March");
			break;
		case 4:
			System.out.println("April");
			break;
		case 5 :
			System.out.println("May");
			break;
		case 6:
			System.out.println("June");
			break;
		case 7 :
			System.out.println("July");
			break;
		case 8 :
			System.out.println("August");
			break;
		case 9 :
			System.out.println("sep");
			break;
		case 10 :
			System.out.println("OCT");
			break;
		case 11:
			System.out.println("Nov");
			break;
		case 12:
			System.out.println("Dec");
			break;
			
			
   }
   
}
   }
}
