package com.nissan.app;
import java.util.Scanner;
public class DemoQuestion7 {
	public static void main(String[] args)
	{
		try{volumeVariables();}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private static void volumeVariables()
	{Scanner sc=new Scanner(System.in);
	System.out.println("Enter the width:");
	System.out.println("Enter the height:");
	System.out.println("Enter the dept:");
		double width=sc.nextInt();
		double height=sc.nextInt();
		double depth=sc.nextInt();
	System.out.println("The volume is:" + volume(width,height,depth));
	}
private static double volume(double width, double height, double depth)
	{
		return (width*height*depth);
	}
}
