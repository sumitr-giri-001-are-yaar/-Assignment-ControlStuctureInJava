package com.nissan.app;

import java.util.Scanner;

public class DemoQuestion5 {
	public static void main(String args[]){
		try{season();}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	private static void season(){
		while (true){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the month:");
		System.out.println("1: if");
		System.out.println("2: switch");
		System.out.println("3:while");
		System.out.println("4:do while");
		System.out.println("5:for");
		int x=sc.nextInt();
		switch(x)
		{
		case 1:
			System.out.println("1. if");
			ifHelp();
			break;
		case 2:
			System.out.println("2. switch");
			switchHelp();
			break;
		case 3:
			System.out.println("3. while");
			whileHelp();
			break;
		case 4:
			System.out.println("4. do-while");
			do_whileHelp();
			break;
		case 5:
			forHelp();
			System.out.println("4. do-while");
			break;
			
			
		
		}
		}
	}
	private static void ifHelp(){
		   System.out.println("if(condition is true) {");
	        System.out.println("\t //statement;");
	        System.out.println("} else {");
	        System.out.println("\t //statement;");
	        System.out.println("}");
	}
	private static void switchHelp(){
		 System.out.println("switch(key) {");
	        System.out.println("\t case1:");
	        System.out.println("\t \t //statements");
	        System.out.println("\t \t break;");
	        System.out.println("\t default:");
	        System.out.println("\t \t //statement");
	        System.out.println("\t \t break;");
	        System.out.println("}");
	}
	private static void whileHelp(){
		 System.out.println("while(condition = true) {");
	        System.out.println("\t //statement");
	        System.out.println("}");
	}
	private static void do_whileHelp(){
	 System.out.println("do {");
    System.out.println("\t //statement");
    System.out.println("} while(condition = true)");}
	private static void forHelp(){
		 System.out.println("for(initialization; condition; increment/decrement) {");
	        System.out.println("\t //statement");
	        System.out.println("}");
	}
	

}
