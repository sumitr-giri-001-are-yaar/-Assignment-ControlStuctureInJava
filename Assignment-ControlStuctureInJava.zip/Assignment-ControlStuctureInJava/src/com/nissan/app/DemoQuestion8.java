package com.nissan.app;
import java.util.Scanner;
public class DemoQuestion8 {
	public static void main(String arga[]){
	try{	Scanner sc=new Scanner(System.in);
		System.out.println("enter the height,width,depth");
		int height=sc.nextInt();
		int width=sc.nextInt();
		int depth=sc.nextInt();
		Volume v=new Volume(height,width,depth);
		System.out.println("the volume is: " +v.volume());
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}

}
class Volume{
	int height;
	int width;
	int depth;
	Volume(int h,int w,int d)
	{
		height=h;
		width=w;
		depth=d;
		
	}
	public int volume(){
		return (height*width*depth);
	}
}
