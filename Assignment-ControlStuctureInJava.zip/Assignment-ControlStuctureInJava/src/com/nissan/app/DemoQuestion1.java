package com.nissan.app;

import java.util.Scanner;

public class DemoQuestion1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			enterDetails();
		} catch (Exception e) {
			System.out.println("data type mismatch ");
		}

	}

	private static double enterDetails() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Choose your area");
			// int x=sc.nextInt();
			// System.out.println("Enter the unit ");
			// int unit=sc.nextInt();
			System.out.println("Option 1:DOMESTIC");
			System.out.println("Option 2:Industrial");
			int option = sc.nextInt();
			System.out.println("Enter the unit ");
			int unit = sc.nextInt();
			// 0-100 then amt=units* Rs.1

			// 100-200amt=units*1.5

			// 200-500amt=units*2

			// >500amt = units*5
			switch (option) {
			case 1:
				System.out.println("DOMESTIC Amount:" + domestic(unit));
				break;
			case 2:
				System.out.println("INDUSTRIAL Amount:" + industrial(unit));
				break;
			default:
					break;

			}
		}
	}

	private static double domestic(int unit) {
		if (unit > 0 && unit <= 100) {
			return unit;
		} else if (unit > 100 && unit <= 200) {
			return unit * 1.5;
		} else if (unit > 200 && unit <= 500) {
			return unit * 2;
		} else {
			return unit * 5;
		}

	}

	private static double industrial(int unit) {
		return unit * 10;
	}

}
