package com.nissan.app;
import java.util.Scanner;
public class DemoQuestion2 {
	public static void main(String args[])
	{   //Scanner sc=new Scanner(System.in);
		try{detailsCustomer();}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
   private static void detailsCustomer(){
	  while(true)
		  {Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR ATM NUMBER");
        int atmNo=sc.nextInt();
		int pinNo=1122;
		System.out.println(verify(pinNo));
		  }
   }
   private static String verify(int pinNo){
	   Scanner s=new Scanner(System.in);
	   System.out.println("ENTER THE PIN");
	   int userPin=s.nextInt();
	   if(userPin==pinNo)
	   {
		   return "AUTHENTICATED";
	   }
	   else
	   {
		   return "WRONG PASSWORD!!";
	   }
	   
   }
}

