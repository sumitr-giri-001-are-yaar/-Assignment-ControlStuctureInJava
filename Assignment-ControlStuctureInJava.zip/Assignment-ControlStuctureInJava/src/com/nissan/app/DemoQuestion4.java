package com.nissan.app;

import java.util.Scanner;

public class DemoQuestion4 {
	public static void main(String args[]){
		try{season();}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	private static void season(){
		while (true){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the month:");
		System.out.println("1: January");
		System.out.println("2: February");
		System.out.println("3: March");
		System.out.println("4:April");
		System.out.println("5:May");
		System.out.println("6:June");
		System.out.println("7:July");
		System.out.println("8:August");
		System.out.println("9:sep");
		System.out.println("10:OCT");
		System.out.println("11:Nov");
		System.out.println("12:Dec");
		int x=sc.nextInt();
		switch(x)
		{
		case 1:
			System.out.println("Winter Season");
			break;
		case 2:
			System.out.println("Winter Season");
			break;
		case 3:
			System.out.println("Spring Season");
			break;
		case 4:
			System.out.println("Spring Season");
			break;
		case 5 :
			System.out.println("Spring Season");
			break;
		case 6:
			System.out.println("Winter Season");
			break;
		case 7 :
			System.out.println("Winter Season");
			break;
		case 8 :
			System.out.println("Winter Season");
			break;
		case 9 :
			System.out.println("Autumn Season");
			break;
		case 10 :
			System.out.println("Autumn Season");
			break;
		case 11:
			System.out.println("Autumn Season");
			break;
		case 12:
			System.out.println("Winter Season");
			break;
			
			
		
		}
		}
	}

}
