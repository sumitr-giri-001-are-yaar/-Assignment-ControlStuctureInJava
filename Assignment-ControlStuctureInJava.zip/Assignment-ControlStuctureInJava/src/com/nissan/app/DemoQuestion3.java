package com.nissan.app;
import java.util.Scanner;
public class DemoQuestion3 {
	public static void main(String args[]){
		try{season();
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	private static void season(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the month:");
		System.out.println("1: January");
		System.out.println("2: February");
		System.out.println("3: March");
		System.out.println("4:April");
		System.out.println("5:May");
		System.out.println("6:June");
		System.out.println("7:July");
		System.out.println("8:August");
		System.out.println("9:sep");
		System.out.println("10:OCT");
		System.out.println("11:Nov");
		System.out.println("12:Dec");
int x=sc.nextInt();
if(x==1 || x==2 || x==12)
{
	System.out.println("Winter Season");
	}
else if(x==3 || x==4 || x==5)
{
	System.out.println("Spring Season");
	}
else if(x==6 || x==7 || x==8)
{
	System.out.println("Winter Season");
	}
else if(x==9 || x==10 || x==11)
{
	System.out.println("Autumn Season");
	}
else
{
	System.out.println("No Season");}
	}
	

}
